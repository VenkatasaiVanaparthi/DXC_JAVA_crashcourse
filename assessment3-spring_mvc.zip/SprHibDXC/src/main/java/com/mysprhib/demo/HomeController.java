package com.mysprhib.demo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysprhib.model.Resturant;
import com.mysprhib.resturantdao.ResturantDao;

@Controller
public class HomeController {
	
	
	@Autowired
	ResturantDao resturantDao;
	
	@RequestMapping(value = "/")
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	@RequestMapping(value = "/saveRest")
	public String saveRest(@ModelAttribute Resturant resturant) {
		resturantDao.saveResturant(resturant);
		return "home";
	}
	
	@RequestMapping(value = "/deleteRest")
	public String deletepage(Locale locale, Model model) {
		return "delete";
	}
	
	@RequestMapping(value = "/delete")
	public String deleteRest(@RequestParam String name) {
		resturantDao.deleteResturant(name);
		return "home";
	}
	
	
	
	@RequestMapping(value = "/disp") 
	  public String search(Model model, @ModelAttribute Resturant resturants)
	{
	  ArrayList<Resturant> restList =  resturantDao.getResturants();
	  model.addAttribute("resturants",restList); 
	  System.out.println(restList);
	  return "display"; 
	  } 
	
	
	  @RequestMapping(value = "/displaybyid")
	  public String searchbyid(Model model, @RequestParam String name) 
	  { Resturant res = resturantDao.getResturant(name); 
	  model.addAttribute("rn",res ); 
	  return "displaybyid"; }
	 

	@RequestMapping(value = "/displaybyloc") 
	  public String searchbyloc()
	{	 
	  return "displaybylocation"; 
	  } 
	
	@RequestMapping(value = "/displaybyloc2") 
	  public String searchbyloc2(Model model, @RequestParam("location") String location)
	{
	  ArrayList<Resturant> res = resturantDao.getResturantByLocation(location);
	  model.addAttribute("rns",res );
	  System.out.println(res);
	  return "displaybyloc2"; 
	  } 
	

	
	
//	
//	@RequestMapping(value = "/display")
//	public String getAllRest()
//	{
//		resturantDao.getResturants(); 
//		
//		return "display";
//		
//	}
//	
	
	
	
	@RequestMapping(value = "/updateRest")
	public String updatepage(Locale locale, Model model) {
		return "update";
	}
	
	@RequestMapping(value = "/update")
	public String updateRest(@ModelAttribute Resturant resturant) {
		resturantDao.updateResturant(resturant);
		return "home";
	} 
}


