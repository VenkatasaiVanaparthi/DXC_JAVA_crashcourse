package com.mysprhib.resturantdao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mysprhib.model.Resturant;

@Component
public class ResturantDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void saveResturant(Resturant resturant){	
	Session session=	sessionFactory.getCurrentSession();
	session.save(resturant);
	}

	
	@Transactional
	public  ArrayList<Resturant> getResturants()
	{
	Session session=sessionFactory.getCurrentSession();
	ArrayList<Resturant> resturants=(ArrayList<Resturant>)session.createQuery("from Resturant").list();	
//	System.out.println(resturants);
	return resturants;
	
	}
	
	
	
	  @Transactional 
	  public ArrayList<Resturant> getResturantByLocation(String location) { 
		  Session session=sessionFactory.getCurrentSession();
		  Query query=session.createQuery("from Resturant where location=:location)");
		  query.setParameter("location", location);
		  ArrayList<Resturant> resturants= (ArrayList<Resturant>)query.list(); 
		  return resturants; 
	  }
	 
	
	
	
	/*
	 * @Transactional public Resturant getResturantbyloc(String location) { Session
	 * session=sessionFactory.getCurrentSession(); Resturant resturant=(Resturant)
	 * session.get(Resturant.class, location); return resturant; }
	 */
	
	
	
	@Transactional
	public  Resturant getResturant(String name)
	{
	Session session=sessionFactory.getCurrentSession();
	Resturant resturant=(Resturant) session.get(Resturant.class, name);	
	return resturant;
	}
	
	
	
	@Transactional
	public String deleteResturant(String name){	
	Session session=	sessionFactory.getCurrentSession();
	//Resturant resturant=getResturant(name);
	Resturant resturant=(Resturant) session.get(Resturant.class, name);
	session.delete(resturant);
	return "Resturant Deleted";
	}
	
	@Transactional
	public void updateResturant(Resturant resturant){	
	Session session=	sessionFactory.getCurrentSession();
	session.update(resturant);
	}
	
	
	public ResturantDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	
	public ResturantDao() {
		}
	
	
}
