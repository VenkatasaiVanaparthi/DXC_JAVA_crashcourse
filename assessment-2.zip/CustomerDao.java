package com.assessment2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;



import com.assessment2.dbutil.DbConn;
import com.assessment2.pojo.Customer;
public class CustomerDao {

	public String saveCustomer(Customer customer)
	{
	try
	{
	Connection con=DbConn.getConnection();
	String sql="insert into customer values(?,?,?)";

	PreparedStatement stat=con.prepareStatement(sql);


	stat.setString(1, customer.getFirst_Name());
	stat.setString(2, customer.getLast_name());
	stat.setString(3, customer.getCust_Id());


	int res= stat.executeUpdate();
	if(res>0)
	return "Customer saved";


	}
	catch (Exception e) {
	e.printStackTrace();
	}

	return "Cannot save Customer";

	}
	
}
