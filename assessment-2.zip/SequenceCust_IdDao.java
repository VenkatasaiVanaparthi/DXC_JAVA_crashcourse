package com.assessment2.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.assessment2.dbutil.DbConn;
import com.assessment2.pojo.Customer;
public class SequenceCust_IdDao {
	public int sequence() {
		try {
/*			String sql1="CREATE SEQUENCE seqCust_id START WITH INCREMENT BY 1;select to_char(seqCust_id.nextval,'FM009') from dual;"
					+ "update Customer SET Cust_id = (cust_id, CAST(next value for seqCust_id as varchar(10))";
	*/	
		
		Connection con=DbConn.getConnection();
        String sql="select to_char(seqcust_id.nextval,'FM009') from dual";
        PreparedStatement smt=con.prepareStatement(sql);
        ResultSet rs=smt.executeQuery();
        rs.next();
        int seq= rs.getInt(1);
        if(seq>0)
               return seq;
        }
        catch (Exception e) {
        e.printStackTrace();
        }
        return 0;
	}

}
