package com.assessment2.service;

import com.assessment2.pojo.Customer;
import com.assessment2.dao.SequenceCust_IdDao;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;

import com.assessment2.dao.CustomerDao;
public class CustomerService {
	
	public static void main(String[] args) {

		CustomerDao dao=new CustomerDao();
		Customer customer=new Customer();
		SequenceCust_IdDao sequence=new SequenceCust_IdDao();
		String First_Name,Last_Name;
		
		int seq=sequence.sequence();

		
		
		@SuppressWarnings("resource")

		Scanner sc=new Scanner(System.in);

		System.out.println("First name of customer");

		First_Name=sc.nextLine();

		System.out.println("Last_name of customer");

		Last_Name=sc.nextLine();

		 

		StringBuilder Cust_Id=new StringBuilder();

		Cust_Id.setLength(0);
		Cust_Id.append(First_Name.charAt(0));
		Cust_Id.append(First_Name.charAt(1));
		Cust_Id.append(Last_Name.charAt(0));
		Cust_Id.append(Last_Name.charAt(1));
		Cust_Id.append(seq);
		
		
		

		customer.setFirst_Name(First_Name);
		customer.setLast_Name(Last_Name);
		customer.setCust_Id(Cust_Id.toString());
		System.out.println(dao.saveCustomer(customer));
		
	}

}
